package com.costanti;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.List;

public class  CostantiWeb {
	public final static String SERVER_HOST = "manpronet.com";
	public static String INDIRIZZO_PORTALE = "";
	public static String INDIRIZZO_PORTALE_GENERICO = "";
	public static String INDIRIZZO_PORTALE_ENCODING = "";
	public static String NAME_ODBC = "";
	final protected static char[] hexArray = "0123456789ABCDEF".toCharArray();
	//public static List<String> arrayPortali = new ArrayList<>();
	public static List<CharSequence> chooseDB = new ArrayList<>();
	public static KeyStore keyStore = null;

	public static String bytesToHex(byte[] bytes) {
		char[] hexChars = new char[bytes.length * 2];
		for ( int j = 0; j < bytes.length; j++ ) {
			int v = bytes[j] & 0xFF;
			hexChars[j * 2] = hexArray[v >>> 4];
			hexChars[j * 2 + 1] = hexArray[v & 0x0F];
		}
		return new String(hexChars);
	}

	public static String convertStreamToString(InputStream is) {
		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		StringBuilder sb = new StringBuilder();
		String line;
		try { while ((line = reader.readLine()) != null) { sb.append(line).append("\n"); } }
		catch (IOException e) { e.printStackTrace();}
		finally { try { is.close();	} catch (IOException e) { e.printStackTrace(); } }
		return sb.toString();
	}
}